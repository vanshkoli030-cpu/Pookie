package com.pookie.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.Date

/** Talks to Claude. Replies are JSON: {"speech": "...", "actions": [...], "observe": false} */
object Brain {
    const val MODEL = "claude-sonnet-5-5"
    private val history = ArrayList<JSONObject>()

    @Synchronized
    fun reset() {
        history.clear()
    }

    private fun system(ctx: Context): String {
        val name = Prefs.get(ctx, "name", "boss").ifBlank { "boss" }
        return """
You are Pookie, a warm, witty, slightly cute personal AI assistant living on the user's Android phone, like Jarvis. Address the user as "$name". Now: ${Date()}.
Reply with ONLY one JSON object, no markdown: {"speech":"short natural sentence(s) to say aloud","actions":[...],"observe":false}
Set "observe":true when you need to SEE the screen after your actions to continue a multi-step task (the app will run your actions, then send you the screen text, then you continue). Max 6 rounds. Set it false when finished.
Actions (JSON objects):
{"type":"open_app","app":"app name as shown on the phone, e.g. WhatsApp"}
{"type":"open_url","url":"https://..."} {"type":"search","query":""} {"type":"youtube","query":""} {"type":"navigate","query":"destination"}
{"type":"call","to":"contact name or number"} {"type":"sms","to":"","body":""} {"type":"whatsapp","to":"","body":""}
{"type":"timer","seconds":300} {"type":"alarm","hour":7,"minute":30}
{"type":"flashlight","on":true} {"type":"volume","percent":50} {"type":"wifi_panel"} {"type":"bluetooth_settings"} {"type":"open_settings","page":"wifi|bluetooth|display|sound|battery|apps|location|main"}
{"type":"global","action":"home|back|recents|notifications|quick_settings|lock|screenshot|power_menu"}
{"type":"click_text","text":"visible text or description of a button"} {"type":"type_text","text":""} {"type":"scroll","direction":"down|up"} {"type":"tap","x":540,"y":1200} {"type":"swipe","x1":540,"y1":1600,"x2":540,"y2":600}
{"type":"read_screen"} {"type":"wait","ms":1000}
Rules: Be brief. Never perform payments, money transfers, deleting accounts/data, or changing passwords; tell the user to do those themselves. If something is impossible, say so honestly. For plain questions just answer in "speech" with no actions.
""".trimIndent()
    }

    /** Blocking. Call from a background thread. */
    fun ask(ctx: Context, text: String): JSONObject {
        val key = Prefs.get(ctx, "apiKey").trim()
        if (key.isEmpty()) {
            return JSONObject().put("speech", "Please open the Pookie app and add your Anthropic key so I can think.")
        }
        val messages: JSONArray
        synchronized(this) {
            history.add(JSONObject().put("role", "user").put("content", text))
            while (history.size > 16) history.removeAt(0)
            while (history.isNotEmpty() && history[0].getString("role") != "user") history.removeAt(0)
            messages = JSONArray()
            history.forEach { messages.put(it) }
        }
        val body = JSONObject()
            .put("model", MODEL)
            .put("max_tokens", 800)
            .put("system", system(ctx))
            .put("messages", messages)

        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
            OutputStreamWriter(conn.outputStream, "UTF-8").use { it.write(body.toString()) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) {
                synchronized(this) { if (history.isNotEmpty()) history.removeAt(history.size - 1) }
                val msg = try {
                    JSONObject(resp).getJSONObject("error").getString("message")
                } catch (e: Exception) {
                    "HTTP $code"
                }
                throw RuntimeException(msg)
            }
            val content = JSONObject(resp).getJSONArray("content")
            val sb = StringBuilder()
            for (i in 0 until content.length()) {
                sb.append(content.getJSONObject(i).optString("text", ""))
            }
            val txt = sb.toString().trim()
            synchronized(this) { history.add(JSONObject().put("role", "assistant").put("content", txt)) }
            return parse(txt)
        } finally {
            conn.disconnect()
        }
    }

    private fun parse(txt: String): JSONObject {
        val i = txt.indexOf('{')
        val k = txt.lastIndexOf('}')
        if (i >= 0 && k > i) {
            try {
                return JSONObject(txt.substring(i, k + 1))
            } catch (e: Exception) {
            }
        }
        return JSONObject().put("speech", txt)
    }
}
