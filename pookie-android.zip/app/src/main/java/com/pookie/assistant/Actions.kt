package com.pookie.assistant

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import org.json.JSONObject

/** Turns Claude's JSON actions into real phone actions. Returns a short result string. */
object Actions {

    private fun launch(ctx: Context, i: Intent): Boolean {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            val a11y = PookieAccessibility.inst
            if (a11y != null) a11y.startActivity(i) else ctx.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun granted(ctx: Context, p: String) =
        ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun findNumber(ctx: Context, who: String): String? {
        val digits = who.filter { it.isDigit() || it == '+' }
        if (digits.length >= 7) return digits
        if (!granted(ctx, Manifest.permission.READ_CONTACTS)) return null
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$who%"),
            null
        )?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        return null
    }

    private fun openAppByName(ctx: Context, name: String): Boolean {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(main, 0)
        val n = name.lowercase().trim()
        val hit = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == n }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(n) }
            ?: list.firstOrNull { n.contains(it.loadLabel(pm).toString().lowercase()) && it.loadLabel(pm).length > 2 }
        val pkg = hit?.activityInfo?.packageName ?: return false
        val i = pm.getLaunchIntentForPackage(pkg) ?: return false
        return launch(ctx, i)
    }

    fun run(ctx: Context, a: JSONObject): String {
        val acc = PookieAccessibility.inst
        try {
            when (a.optString("type")) {
                "open_app" -> {
                    val app = a.optString("app")
                    return if (openAppByName(ctx, app)) "Opened $app" else "Could not find app $app"
                }
                "open_url" -> {
                    launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))))
                    return "Opened link"
                }
                "search" -> {
                    launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.optString("query")))))
                    return "Searched"
                }
                "youtube" -> {
                    launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(a.optString("query")))))
                    return "Opened YouTube search"
                }
                "navigate" -> {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(a.optString("query"))))
                    i.setPackage("com.google.android.apps.maps")
                    if (!launch(ctx, i)) {
                        launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("query")))))
                    }
                    return "Started navigation"
                }
                "call" -> {
                    val who = a.optString("to")
                    val num = findNumber(ctx, who) ?: return "No number found for $who"
                    val action = if (granted(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
                    launch(ctx, Intent(action, Uri.parse("tel:" + Uri.encode(num))))
                    return "Calling $who"
                }
                "sms" -> {
                    val who = a.optString("to")
                    val num = findNumber(ctx, who) ?: return "No number found for $who"
                    val body = a.optString("body")
                    if (granted(ctx, Manifest.permission.SEND_SMS)) {
                        val sm = ctx.getSystemService(SmsManager::class.java)
                        sm.sendMultipartTextMessage(num, null, sm.divideMessage(body), null, null)
                        return "Sent SMS to $who"
                    }
                    val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$num"))
                    i.putExtra("sms_body", body)
                    launch(ctx, i)
                    return "Opened SMS draft"
                }
                "whatsapp" -> {
                    val who = a.optString("to")
                    val num = findNumber(ctx, who)?.replace("+", "") ?: return "No number found for $who"
                    var n = num
                    if (n.length == 10) n = "91$n"
                    launch(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + Uri.encode(a.optString("body")))))
                    if (acc != null && a.optString("body").isNotEmpty()) {
                        Thread {
                            for (t in 1..6) {
                                Thread.sleep(1200)
                                if (acc.clickDesc("Send")) break
                            }
                        }.start()
                        return "Opened WhatsApp chat with $who and pressing Send"
                    }
                    return "Opened WhatsApp chat with $who (tap send)"
                }
                "timer" -> {
                    val i = Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    launch(ctx, i)
                    return "Timer set"
                }
                "alarm" -> {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                        .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    launch(ctx, i)
                    return "Alarm set"
                }
                "flashlight" -> {
                    val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                    val id = cm.cameraIdList.firstOrNull() ?: return "No flashlight"
                    cm.setTorchMode(id, a.optBoolean("on", true))
                    return "Flashlight " + (if (a.optBoolean("on", true)) "on" else "off")
                }
                "volume" -> {
                    val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, (max * a.optInt("percent", 50) / 100), 0)
                    return "Volume set"
                }
                "wifi_panel" -> {
                    launch(ctx, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
                    return "Opened Wi-Fi panel"
                }
                "bluetooth_settings" -> {
                    launch(ctx, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                    return "Opened Bluetooth settings"
                }
                "open_settings" -> {
                    val act = when (a.optString("page")) {
                        "wifi" -> Settings.ACTION_WIFI_SETTINGS
                        "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                        "display" -> Settings.ACTION_DISPLAY_SETTINGS
                        "sound" -> Settings.ACTION_SOUND_SETTINGS
                        "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                        "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                        "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                        else -> Settings.ACTION_SETTINGS
                    }
                    launch(ctx, Intent(act))
                    return "Opened settings"
                }
                "global" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    return if (acc.global(a.optString("action"))) "Done" else "Failed"
                }
                "click_text" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    val t = a.optString("text")
                    return if (acc.clickText(t)) "Clicked '$t'" else "Could not find '$t' on screen"
                }
                "type_text" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    return if (acc.typeText(a.optString("text"))) "Typed" else "No text field found"
                }
                "scroll" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    return if (acc.scroll(a.optString("direction", "down") != "up")) "Scrolled" else "Nothing to scroll"
                }
                "tap" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    acc.tap(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())
                    return "Tapped"
                }
                "swipe" -> {
                    if (acc == null) return "Accessibility is not enabled"
                    acc.swipe(
                        a.optDouble("x1").toFloat(), a.optDouble("y1").toFloat(),
                        a.optDouble("x2").toFloat(), a.optDouble("y2").toFloat()
                    )
                    return "Swiped"
                }
                "read_screen" -> return "" // screen text is attached automatically when observe=true
                "wait" -> {
                    Thread.sleep(a.optLong("ms", 1000).coerceIn(0, 5000))
                    return ""
                }
            }
        } catch (e: Exception) {
            return "Action failed: " + (e.message ?: e.javaClass.simpleName)
        }
        return "Unknown action"
    }
}
