package com.pookie.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts Pookie after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Prefs.getBool(ctx, "enabled", false)) return
        try {
            ctx.startForegroundService(Intent(ctx, PookieService::class.java))
        } catch (e: Exception) {
            // Newer Android blocks starting a microphone service straight from boot.
            // Show a tap-to-start notification; the accessibility service also tries again.
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("boot", "Pookie start", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java).putExtra("autostart", true),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(ctx, "boot")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("Pookie")
                .setContentText("Tap to wake Pookie up")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(2, n)
        }
    }
}
