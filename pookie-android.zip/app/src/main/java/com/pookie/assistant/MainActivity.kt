package com.pookie.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var apiKey: EditText
    private lateinit var name: EditText
    private lateinit var lang: EditText
    private lateinit var picoKey: EditText
    private lateinit var test: EditText
    private val PICK_PPN = 77

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String, size: Float = 14f, color: Int = Color.parseColor("#BDB4EA")): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        v.setPadding(0, dp(12), 0, dp(4))
        return v
    }

    private fun edit(hint: String, value: String, password: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#7F77AA"))
        e.setSingleLine(true)
        if (password) e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(Color.parseColor("#2B2260"))
        e.background = bg
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        return e
    }

    private fun btn(t: String, primary: Boolean = false, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(if (primary) Color.parseColor("#2A1650") else Color.WHITE)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(16).toFloat()
        bg.setColor(Color.parseColor(if (primary) "#FF7AC8" else "#3B3080"))
        b.background = bg
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(8)
        b.layoutParams = lp
        b.setOnClickListener { onClick() }
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#1A1040")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(20), dp(24), dp(20), dp(40))
        root.setBackgroundColor(Color.parseColor("#1A1040"))

        val title = TextView(this)
        title.text = "🎀 Pookie"
        title.textSize = 32f
        title.setTextColor(Color.parseColor("#FF9ED6"))
        title.gravity = Gravity.CENTER
        root.addView(title)
        val sub = TextView(this)
        sub.text = "Your always-listening personal AI.\nSay \"Pookie\" even with the screen off."
        sub.setTextColor(Color.parseColor("#BDB4EA"))
        sub.gravity = Gravity.CENTER
        root.addView(sub)

        status = TextView(this)
        status.setTextColor(Color.WHITE)
        status.textSize = 15f
        status.setPadding(dp(14), dp(14), dp(14), dp(14))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dp(16).toFloat()
        sbg.setColor(Color.parseColor("#2B2260"))
        status.background = sbg
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(16)
        status.layoutParams = slp
        root.addView(status)

        root.addView(label("STEP 1 — Pookie's brain (Anthropic API key)"))
        apiKey = edit("sk-ant-…", Prefs.get(this, "apiKey"), true)
        root.addView(apiKey)
        root.addView(label("What should I call you?"))
        name = edit("boss", Prefs.get(this, "name"))
        root.addView(name)
        root.addView(label("Language (en-IN, en-US, hi-IN …)"))
        lang = edit("en-IN", Prefs.get(this, "lang", "en-IN"))
        root.addView(lang)

        root.addView(label("OPTIONAL — better wake word (Picovoice)"))
        picoKey = edit("Picovoice AccessKey", Prefs.get(this, "picoKey"), true)
        root.addView(picoKey)
        root.addView(btn("Choose Pookie.ppn file") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, PICK_PPN)
        })

        root.addView(btn("Save settings", true) { save(); toast("Saved 💗") })

        root.addView(label("STEP 2 — Permissions (tap each one)"))
        root.addView(btn("1. Allow microphone, calls, texts, contacts") {
            val perms = arrayListOf(
                Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS
            )
            if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(perms.toTypedArray(), 1)
        })
        root.addView(btn("2. Turn on Pookie in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            toast("Find Pookie → turn it on")
        })
        root.addView(btn("3. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("4. Don't let battery saver kill Pookie") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(btn("If step 2 is greyed out: open App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            toast("Tap ⋮ (top right) → Allow restricted settings")
        })

        root.addView(label("STEP 3 — Start!"))
        root.addView(btn("▶ Start Pookie", true) { save(); startPookie() })
        root.addView(btn("■ Stop Pookie") {
            startService(Intent(this, PookieService::class.java).setAction("STOP"))
            Prefs.setBool(this, "enabled", false)
            toast("Pookie stopped")
        })

        root.addView(label("Test without talking"))
        test = edit("e.g. call mom / open WhatsApp", "")
        root.addView(test)
        root.addView(btn("Send to Pookie") {
            val t = test.text.toString().trim()
            if (t.isNotEmpty()) {
                save()
                try {
                    startForegroundService(Intent(this, PookieService::class.java).setAction("TEXT").putExtra("text", t))
                } catch (e: Exception) {
                    toast("Could not start: " + e.message)
                }
                test.setText("")
            }
        })

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)

        if (intent?.getBooleanExtra("autostart", false) == true) startPookie()
    }

    private fun save() {
        Prefs.set(this, "apiKey", apiKey.text.toString().trim())
        Prefs.set(this, "name", name.text.toString().trim())
        Prefs.set(this, "lang", lang.text.toString().trim().ifEmpty { "en-IN" })
        Prefs.set(this, "picoKey", picoKey.text.toString().trim())
    }

    private fun startPookie() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            toast("Please allow the microphone first (button 1)")
            return
        }
        try {
            startForegroundService(Intent(this, PookieService::class.java))
            toast("Pookie is listening 🎀")
        } catch (e: Exception) {
            toast("Could not start: " + e.message)
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val acc = PookieAccessibility.inst != null
        val overlay = Settings.canDrawOverlays(this)
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        val batt = pm.isIgnoringBatteryOptimizations(packageName)
        val ppn = File(Prefs.get(this, "ppnPath")).exists()
        fun c(b: Boolean) = if (b) "✅" else "⬜"
        status.text = "${c(mic)} Microphone & permissions\n" +
                "${c(acc)} Accessibility (screen control)\n" +
                "${c(overlay)} Display over other apps\n" +
                "${c(batt)} Battery unrestricted\n" +
                "${c(ppn)} Custom wake word file (optional)\n" +
                "${c(Prefs.get(this, "apiKey").isNotBlank())} Anthropic key"
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_PPN && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val out = File(filesDir, "pookie.ppn")
                contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } }
                Prefs.set(this, "ppnPath", out.absolutePath)
                toast("Wake word file loaded ✅")
                updateStatus()
            } catch (e: Exception) {
                toast("Could not read file: " + e.message)
            }
        }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()
}
