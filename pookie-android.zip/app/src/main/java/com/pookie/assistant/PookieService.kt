package com.pookie.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import ai.picovoice.porcupine.PorcupineManager
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * The always-on part. Runs as a foreground service so it keeps listening with the screen off.
 * Flow: wait for "Pookie" -> listen for the command -> ask Claude -> do the actions -> speak -> wait again.
 */
class PookieService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var porcupine: PorcupineManager? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var busy = false
    private var woke = false
    private var pending = 0
    private var turnDone = true
    private var started = false

    private val wakeRegex = Regex("(pookie|pooky|pookey|pukki|pooki|bookie|pookies|poki)")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("pookie", "Pookie is listening", NotificationManager.IMPORTANCE_LOW))
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pookie:listen").apply {
            setReferenceCounted(false)
            acquire()
        }
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val lang = Prefs.get(this, "lang", "en-IN")
                val r = tts?.setLanguage(Locale.forLanguageTag(lang))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.setLanguage(Locale.US)
                }
                tts?.setPitch(1.1f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) {
                        main.post { pending--; maybeResume() }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        main.post { pending--; maybeResume() }
                    }
                })
                ttsReady = true
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            Prefs.setBool(this, "enabled", false)
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val n = buildNotif("Starting…")
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        Prefs.setBool(this, "enabled", true)
        if (intent?.action == "TEXT") {
            val t = intent.getStringExtra("text")
            if (!t.isNullOrBlank()) main.post { handleText(t) }
        } else if (!started) {
            started = true
            main.post { startWake() }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        stopAll()
        tts?.shutdown()
        try {
            wakeLock?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }

    // ---------- notification ----------
    private fun buildNotif(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, PookieService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, "pookie")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Pookie")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
                ).build()
            )
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(1, buildNotif(text))
    }

    // ---------- listening for the wake word ----------
    private fun stopAll() {
        try {
            porcupine?.stop()
            porcupine?.delete()
        } catch (e: Exception) {
        }
        porcupine = null
        try {
            recognizer?.cancel()
            recognizer?.destroy()
        } catch (e: Exception) {
        }
        recognizer = null
    }

    private fun startWake() {
        stopAll()
        if (busy) return
        woke = false
        val key = Prefs.get(this, "picoKey").trim()
        val ppn = Prefs.get(this, "ppnPath")
        if (key.isNotEmpty() && ppn.isNotEmpty() && File(ppn).exists()) {
            try {
                porcupine = PorcupineManager.Builder()
                    .setAccessKey(key)
                    .setKeywordPath(ppn)
                    .setSensitivity(0.7f)
                    .build(this) { _ -> main.post { onWake("") } }
                porcupine?.start()
                updateNotif("Say \"Pookie\" anytime")
                return
            } catch (e: Exception) {
                updateNotif("Wake word engine failed (" + (e.message ?: "error") + "), using basic mode")
            }
        }
        startSpeechWake()
    }

    private fun startSpeechWake() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateNotif("Speech recognition is not available on this phone")
            return
        }
        updateNotif("Say \"Pookie\" anytime")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (!checkWake(t)) restartWake(400)
            }

            override fun onError(error: Int) {
                restartWake(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 500)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(recognizerIntent())
    }

    private fun recognizerIntent(): Intent =
        Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(this, "lang", "en-IN"))
            .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra("android.speech.extra.SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS", 1500L)

    private fun restartWake(delayMs: Long) {
        main.postDelayed({ if (!busy && !woke) startWake() }, delayMs)
    }

    private fun checkWake(text: String): Boolean {
        val t = text.lowercase()
        val m = wakeRegex.find(t) ?: return false
        woke = true
        val rest = t.substring(m.range.last + 1).trim().trimStart(',', '.', ' ')
        main.post { onWake(rest) }
        return true
    }

    private fun onWake(rest: String) {
        woke = true
        stopAll()
        if (rest.length > 2) {
            handleText(rest)
        } else {
            try {
                ToneGenerator(AudioManager.STREAM_MUSIC, 70).startTone(ToneGenerator.TONE_PROP_ACK, 150)
            } catch (e: Exception) {
            }
            main.postDelayed({ listenCommand() }, 350)
        }
    }

    // ---------- listening for the command ----------
    private fun listenCommand() {
        updateNotif("Listening…")
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                if (t.isBlank()) {
                    woke = false
                    startWake()
                } else {
                    handleText(t)
                }
            }

            override fun onError(error: Int) {
                woke = false
                restartWake(300)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        r.startListening(recognizerIntent())
    }

    // ---------- thinking + doing ----------
    private fun handleText(text: String) {
        stopAll()
        busy = true
        turnDone = false
        updateNotif("Thinking… \"" + text.take(40) + "\"")
        Thread {
            var input = text
            var steps = 0
            try {
                while (steps < 6) {
                    steps++
                    val r: JSONObject = Brain.ask(this, input)
                    val speech = r.optString("speech")
                    if (speech.isNotBlank()) speak(speech)
                    val obs = StringBuilder()
                    val acts = r.optJSONArray("actions")
                    if (acts != null) {
                        for (i in 0 until acts.length()) {
                            val res = Actions.run(this, acts.getJSONObject(i))
                            if (res.isNotEmpty()) obs.append(res).append('\n')
                        }
                    }
                    if (r.optBoolean("observe")) {
                        Thread.sleep(1500)
                        val screen = PookieAccessibility.inst?.readScreen()
                            ?: "(Accessibility is not enabled, so I cannot see the screen)"
                        input = "Action results:\n$obs\nScreen now:\n$screen"
                    } else {
                        break
                    }
                }
            } catch (e: Exception) {
                speak("Sorry, I had a problem. " + (e.message ?: ""))
            }
            main.post { turnDone = true; maybeResume() }
        }.start()
    }

    private fun speak(text: String) {
        main.post {
            if (ttsReady) {
                pending++
                tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "u" + System.nanoTime())
            }
        }
    }

    private fun maybeResume() {
        if (turnDone && pending <= 0) {
            pending = 0
            busy = false
            woke = false
            main.postDelayed({ startWake() }, 500)
        }
    }
}
